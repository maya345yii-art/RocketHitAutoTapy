# Rocket Hit Auto Tap

Android Studio source project for a user-controlled multi-position tap helper.

Features:
- Repeated taps at a list of user-entered screen coordinates
- Normal default delay: 300 ms (adjustable from 150–5000 ms)
- Start and Stop buttons
- Optional tap on explicitly labelled visible Skip / Close / Dismiss buttons exposed by Android Accessibility

Limitations:
- Cannot bypass ad timers, force-dismiss an ad without a visible control, or skip ads that require watching for rewards.
- Some apps do not expose ad controls to Accessibility; auto-dismiss will not work in those cases.
- Does not read or upload screen content.
- Do not place game tap coordinates on ads, purchases, or system controls.

## Build APK
1. Extract this ZIP.
2. Open the `RocketHitAutoTap` folder in Android Studio.
3. Allow Gradle sync; install Android SDK Platform 35 if prompted and use JDK 17.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Use the build notification's **Locate** link. Expected output: `app/build/outputs/apk/debug/app-debug.apk`.
6. Transfer the APK to your Android phone and install it.

## Setup
1. Open Rocket Hit Auto Tap.
2. Tap **Open Accessibility Settings**.
3. Enable Rocket Hit Auto Tap under installed/downloaded accessibility services.
4. Enter coordinates, one `x,y` pair per line.
5. Enable the optional Skip/Close checkbox if desired.
6. Open Rocket Hit, return to the tapper, and press Start. Press Stop to stop all tapping.
