package com.example.rockethitautotap

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.Locale

class RocketTapService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var running = false
    private var points: List<Pair<Float, Float>> = emptyList()
    private var delayMs = 300L
    private var nextIndex = 0
    private var receiverRegistered = false
    private var lastDismissAt = 0L

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                ACTION_START -> startTapping()
                ACTION_STOP -> stopTapping()
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        val filter = IntentFilter().apply {
            addAction(ACTION_START)
            addAction(ACTION_STOP)
        }
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(receiver, filter)
        }
        receiverRegistered = true
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!running || event == null) return
        val enabled = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
            .getBoolean(MainActivity.KEY_SKIP, true)
        if (!enabled || System.currentTimeMillis() - lastDismissAt < 1800L) return

        val root = rootInActiveWindow ?: return
        val button = findDismissControl(root) ?: return
        if (button.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
            lastDismissAt = System.currentTimeMillis()
            handler.removeCallbacks(tapRunnable)
            handler.postDelayed(tapRunnable, 1200L)
        }
    }

    private fun findDismissControl(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val label = listOfNotNull(
            node.text?.toString(),
            node.contentDescription?.toString()
        ).joinToString(" ").lowercase(Locale.ROOT).trim()

        val allowed = setOf(
            "skip", "skip ad", "skip video", "close", "close ad",
            "close video", "dismiss", "dismiss ad"
        )
        val buttonLike = node.isClickable &&
            (node.className?.toString()?.contains("Button", true) == true || node.isFocusable)
        if (buttonLike && label in allowed) return node

        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = findDismissControl(child)
            if (found != null) return found
        }
        return null
    }

    override fun onInterrupt() = stopTapping()

    private fun startTapping() {
        val prefs = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
        points = prefs.getString(MainActivity.KEY_POINTS, "340,900\n500,1100")
            .orEmpty().lines().mapNotNull { line ->
                val p = line.trim().split(",")
                if (p.size != 2) null else {
                    val x = p[0].trim().toFloatOrNull()
                    val y = p[1].trim().toFloatOrNull()
                    if (x != null && y != null && x >= 0 && y >= 0) x to y else null
                }
            }
        delayMs = prefs.getInt(MainActivity.KEY_DELAY, 300).toLong().coerceIn(150L, 5000L)
        if (points.isEmpty()) return
        running = true
        nextIndex = 0
        handler.removeCallbacks(tapRunnable)
        handler.post(tapRunnable)
    }

    private val tapRunnable = object : Runnable {
        override fun run() {
            if (!running || points.isEmpty()) return
            val (x, y) = points[nextIndex % points.size]
            val path = Path().apply { moveTo(x, y) }
            val gesture = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, 60))
                .build()
            dispatchGesture(gesture, null, null)
            nextIndex = (nextIndex + 1) % points.size
            if (running) handler.postDelayed(this, delayMs)
        }
    }

    private fun stopTapping() {
        running = false
        handler.removeCallbacks(tapRunnable)
    }

    override fun onDestroy() {
        stopTapping()
        if (receiverRegistered) unregisterReceiver(receiver)
        super.onDestroy()
    }

    companion object {
        const val ACTION_START = "com.example.rockethitautotap.START"
        const val ACTION_STOP = "com.example.rockethitautotap.STOP"
    }
}
