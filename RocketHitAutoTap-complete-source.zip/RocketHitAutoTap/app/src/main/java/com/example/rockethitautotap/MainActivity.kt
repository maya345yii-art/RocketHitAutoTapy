package com.example.rockethitautotap

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private lateinit var pointsInput: EditText
    private lateinit var intervalInput: EditText
    private lateinit var skipToggle: CheckBox

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 20, 20, 20)
        }
        content.addView(TextView(this).apply {
            text = "🚀 Rocket Hit Auto Tap"
            textSize = 24f
        }, matchWrap())
        content.addView(TextView(this).apply {
            text = "Multi-position mode • Normal default: 300 ms"
            textSize = 15f
        }, matchWrap())

        content.addView(TextView(this).apply {
            text = "Tap positions (screen pixels; x,y per line)"
            setPadding(0, 18, 0, 4)
        }, matchWrap())
        pointsInput = EditText(this).apply {
            setText(prefs.getString(KEY_POINTS, "340,900\n500,1100"))
            hint = "340,900\n500,1100"
            minLines = 4
            gravity = Gravity.TOP
            inputType = android.text.InputType.TYPE_CLASS_TEXT or
                android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE
        }
        content.addView(pointsInput, matchWrap())

        content.addView(TextView(this).apply {
            text = "Delay between taps (150–5000 ms)"
            setPadding(0, 12, 0, 4)
        }, matchWrap())
        intervalInput = EditText(this).apply {
            setText(prefs.getInt(KEY_DELAY, 300).toString())
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
        }
        content.addView(intervalInput, matchWrap())

        skipToggle = CheckBox(this).apply {
            text = "Auto-tap visible Skip / Close ad buttons"
            isChecked = prefs.getBoolean(KEY_SKIP, true)
        }
        content.addView(skipToggle, matchWrap())
        content.addView(TextView(this).apply {
            text = "This only taps clearly labelled visible Skip/Close/Dismiss controls exposed by Android. It cannot bypass ad timers or skip ads that require watching for rewards. Do not put game tap coordinates on ads, purchases, or system controls."
            textSize = 13f
            setPadding(0, 4, 0, 12)
        }, matchWrap())

        content.addView(Button(this).apply {
            text = "1. Open Accessibility Settings"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }, matchWrap())

        content.addView(Button(this).apply {
            text = "START AUTO PLAY"
            setOnClickListener {
                if (parsePoints(pointsInput.text.toString()).isEmpty()) {
                    toast("Enter at least one valid x,y position.")
                    return@setOnClickListener
                }
                val delay = intervalInput.text.toString().toIntOrNull() ?: 300
                if (delay !in 150..5000) {
                    toast("Choose a delay from 150 to 5000 ms.")
                    return@setOnClickListener
                }
                prefs.edit()
                    .putString(KEY_POINTS, pointsInput.text.toString())
                    .putInt(KEY_DELAY, delay)
                    .putBoolean(KEY_SKIP, skipToggle.isChecked)
                    .apply()
                sendBroadcast(Intent(RocketTapService.ACTION_START).setPackage(packageName))
                toast("Start requested. Enable the Accessibility service first if needed.")
            }
        }, matchWrap())

        content.addView(Button(this).apply {
            text = "STOP AUTO PLAY"
            setOnClickListener {
                sendBroadcast(Intent(RocketTapService.ACTION_STOP).setPackage(packageName))
                toast("Stop requested.")
            }
        }, matchWrap())

        setContentView(ScrollView(this).apply { addView(content) })
    }

    private fun parsePoints(raw: String): List<Pair<Float, Float>> =
        raw.lines().mapNotNull { line ->
            val p = line.trim().split(",")
            if (p.size != 2) null else {
                val x = p[0].trim().toFloatOrNull()
                val y = p[1].trim().toFloatOrNull()
                if (x != null && y != null && x >= 0 && y >= 0) x to y else null
            }
        }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    )
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    companion object {
        const val PREFS = "rocket_tap_settings"
        const val KEY_POINTS = "points"
        const val KEY_DELAY = "delay"
        const val KEY_SKIP = "skip_visible_ad_buttons"
    }
}
